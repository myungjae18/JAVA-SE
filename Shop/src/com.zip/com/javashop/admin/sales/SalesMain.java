package com.javashop.admin.sales;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

public class SalesMain extends JPanel{
	public SalesMain() {
		setBackground(Color.YELLOW);
		setPreferredSize(new Dimension(1200, 650));
	}
}
