package com.javashop.admin.member;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

public class	MemberMain extends JPanel{
	public MemberMain() {
		setBackground(Color.RED);
		setPreferredSize(new Dimension(1200, 650));
	}
}
