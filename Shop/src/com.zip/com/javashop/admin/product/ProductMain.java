package com.javashop.admin.product;

import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.javashop.admin.Main;
import com.javashop.util.StringUtil;

public class ProductMain extends JPanel{
	Main main;
	JPanel p_west; //���ǰ ����
	JPanel  p_east; //�󼼺��� ����
	Choice ch_top; //���� ī�װ���
	Choice ch_sub; //���� ī�װ���
	JTextField t_name, t_price;
	Canvas can_regist;
	JButton bt_find, bt_regist;
	JFileChooser chooser;
	Image regist_img;
	String regist_path; //��� �� ����� �̹��� ���
	
	PreparedStatement pstmt=null;
	ResultSet rs=null;
		
	//���� ī�װ����� primary key�� ���� �迭
	ArrayList top_list=new ArrayList();
	ArrayList sub_list=new ArrayList();
	
	public ProductMain(Main main) {
		this.main=main;
		
		p_west=new JPanel();
		p_east=new JPanel();
		ch_top=new Choice();
		ch_sub=new Choice();
		t_name=new JTextField();
		t_price=new JTextField();
		bt_find=new JButton("����ã��");
		bt_regist=new JButton("���");
		can_regist=new Canvas() {
			public void paint(Graphics g) {
				g.setColor(Color.RED);
				g.drawImage(regist_img, 0, 0, 145, 145, null);
			}
		};
		chooser=new JFileChooser("E:/java_developer/javaSE/Project0107/res/xerathFace.png");
		
		setLayout(new BorderLayout());
		
		Dimension d=new Dimension(145, 25);
		
		ch_top.setPreferredSize(d);
		ch_sub.setPreferredSize(d);
		t_name.setPreferredSize(d);
		t_price.setPreferredSize(d);
		can_regist.setPreferredSize(new Dimension(145, 145));
		bt_find.setPreferredSize(d);
		bt_regist.setPreferredSize(d);
		
		p_west.setPreferredSize(new Dimension(170, 600));		
		p_west.add(ch_top);
		p_west.add(ch_sub);
		p_west.add(t_name);
		p_west.add(t_price);
		p_west.add(can_regist);
		p_west.add(bt_find);
		p_west.add(bt_regist);
		
		add(p_west, BorderLayout.WEST);
		
		setBackground(Color.WHITE);
		setPreferredSize(new Dimension(1200, 650));
		
		//ch_top ���̽� ������Ʈ�� ������ ����
		ch_top.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int index=ch_top.getSelectedIndex();
				Integer obj=(Integer)top_list.get(index);
				getSubList(obj);				
			}
		});
		
		bt_find.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openFile();
			}
		});
		
		bt_regist.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				regist();
			}
		});
		
		//���̽� ������Ʈ�� �� ä���
		getTopList();
	}
	//�ֻ��� ī�װ��� ���ϱ�
	public void getTopList() {
		Connection con=main.getCon();
		try {
			String sql="select * from topcategory";
			pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			//rs�� ������ choice�� �ű��
			while(rs.next()) {
				ch_top.add(rs.getString("name"));
				/*getInt�� int���� ��ȯ�ϰ�, add() �޼���� Object���� �μ��� �־�� �ϹǷ�,
				���� ���� ���� �ʾ� ������ ����� ������, �ڹٿ����� �⺻ �ڷ����� ���۷��� Ŭ������
				�ڵ� ����ȯ�� �����Ѵ�..�̷� ������ ������ boxing�̶� �Ѵ�..
				int->integer : AutoBoxing*/
				top_list.add(rs.getInt("topcategory_id")); 
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	//���� ī�װ��� ���ϱ�
	public void getSubList(int topcategory_id) {
		Connection con=main.getCon();
		try {
			String sql="select * from subcategory where topcategory_id="+topcategory_id;
			pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			
			ch_sub.removeAll();
			sub_list.removeAll(sub_list);
			while(rs.next()) {
				ch_sub.add(rs.getString("name"));
				sub_list.add(rs.getInt("subcategory_id"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	//���� ã�� �޼��� ����
	public void openFile() {
		int result=chooser.showOpenDialog(this);
		if(result==JFileChooser.APPROVE_OPTION) {
			File file=chooser.getSelectedFile();
			regist_path=file.getAbsolutePath();	
			//System.out.println(file.getAbsolutePath());
			ImageIcon icon=new ImageIcon(file.getAbsolutePath());
			regist_img=icon.getImage();
			can_regist.repaint();
		}
	}
	public void regist() {
		Connection con=main.getCon();
		int index=ch_sub.getSelectedIndex();
		int subcategory_id=(Integer)sub_list.get(index);
		String name=t_name.getText();
		String price=t_price.getText();
		String imgName=System.currentTimeMillis()+"."+StringUtil.getExt(regist_path);
		//System.out.println(imgName);
		String sql="insert into product(product_id, subcategory_id, product_name, price, img)";
		sql+=" values(seq_product.nextval, "+subcategory_id+", '"+name+"', "+price+", '"+imgName+"')";
		System.out.println(sql);
		
		try {
			pstmt=con.prepareStatement(sql);
			int result=pstmt.executeUpdate();
			if(result==0) {
				JOptionPane.showMessageDialog(this, "��� ����");
			}else {
				JOptionPane.showMessageDialog(this, "��� ����");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
