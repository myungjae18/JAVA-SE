package com.javashop.admin.chat;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

public class ChatMain extends JPanel{
	public ChatMain() {
		setBackground(Color.BLUE);
		setPreferredSize(new Dimension(1200, 650));
	}
}
